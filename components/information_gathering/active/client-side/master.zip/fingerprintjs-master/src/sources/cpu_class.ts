export default function getCpuClass(): string | undefined {
  return navigator.cpuClass
}

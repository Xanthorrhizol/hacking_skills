export default function getColorDepth(): number {
  return window.screen.colorDepth
}

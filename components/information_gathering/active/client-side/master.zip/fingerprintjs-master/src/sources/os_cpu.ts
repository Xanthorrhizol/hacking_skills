export default function getOsCpu(): string | undefined {
  return navigator.oscpu
}
